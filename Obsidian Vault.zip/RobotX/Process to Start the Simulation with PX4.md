---
tags:
  - Robotx
  - PX4
created: 2025-12-18 10:47
---

# Process to Start the Simulation with PX4

---

## Summary
This is a file showing the process an user needs to use to integrate the PX4 UAVs with the VRX world. The step are presented next:
1. Add the PX4 required plugins to the world file you want to open, such as: gz-sim-physics-system, gz-sim-user-commands-system, gz-sim-scene-broadcaster-system, gz-sim-contact-system, sim-imu-system, gz-sim-air-pressure-system, gz-sim-apply-link-wrench-system, gz-sim-navsat-system, and gz-sim-sensors-system.
2. Add the VRX world with models to the PX4 Simulations/gz world and models folder. 	```
3. Paste all the models folder related to the corresponding UAV to the VRX gz models folder.
4. Launch the VRX launch file
	``` bash
	ros2 launch vrx_gz competition.launch.py world:=sydney_regatta 
	```
5. Spawn the UAV using the PX4 standalone launcher in the position you want, for example: 
		``` PX4_GZ_STANDALONE=1 PX4_GZ_WORLD=sydney_regatta PX4_GZ_MODEL_POSE="-540,140,4,0,0,1.5708" make px4_sitl gz_x500```
6. Start the QGround Control:
	```bash 
	Open the AppImage
	```



**NOTE:** In case hte ignition gazbeo is open instead of gz sim 7 remember to download the garden versions of gz_ro_humbl libraries:
``` bash
sudo apt install ros-humble-ros-gzgarden-bridge ros-humble-ros-gzgarden-sim ros-humble-ros-gzgarden-interfaces
```

**IMPORTANT:** To build the VRX package you need to ``` colcon build --merge-install``` so the updates can be seen in the install folde

**IMPORTANT:** 