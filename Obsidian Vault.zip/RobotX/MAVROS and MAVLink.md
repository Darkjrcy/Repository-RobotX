---
tags:
  - PX4
  - ROS2
  - Robotx
created: 2026-01-06 11:37
---

# MAVROS and MAVLink

---
## 1. PX4 Offboard rules

The vehicle obeys position, velocity, acceleration, attitude, attitude rates or thrust/torque setpoints provided by some source that is external to the flight stack, such as a companion computer. The setpoints may be provided using MAVLink (or a MAVLink API such as [MAVSDK](https://mavsdk.mavlink.io/)) or by [ROS 2](https://docs.px4.io/main/en/ros2/). PX4 requires that the external controller provides a continuous 2Hz "proof of life" signal, by streaming any of the supported MAVLink setpoint messages or the ROS 2 [OffboardControlMode](https://docs.px4.io/main/en/msg_docs/OffboardControlMode) message. PX4 enables offboard control only after receiving the signal for more than a second, and will regain control if the signal stops.

**INFO:**  The vehicle must be already be receiving a stream of MAVLink setpoint messages or ROS 2 [OffboardControlMode](https://docs.px4.io/main/en/msg_docs/OffboardControlMode) messages before arming in offboard mode or switching to offboard mode when flying. The vehicle will exit offboard mode if MAVLink setpoint messages or `OffboardControlMode` are not received at a rate of > 2Hz.
 
 **Offboard mode** is used for controlling vehicle movement and attitude, by setting position, velocity, acceleration, attitude, attitude rates or thrust/torque setpoints. PX4 must receive a stream of MAVLink setpoint messages or the ROS 2 [OffboardControlMode](https://docs.px4.io/main/en/msg_docs/OffboardControlMode) at 2 Hz as proof that the external controller is healthy. The stream must be sent for at least a second before PX4 will arm in offboard mode, or switch to offboard mode when flying.
 
When using MAVLink the setpoint messages convey both the signal to indicate that the external source is "alive", and the setpoint value itself. In order to hold position in this case the vehicle must receive a stream of setpoints for the current position. When using ROS 2 the proof that the external source is alive is provided by a stream of [OffboardControlMode](https://docs.px4.io/main/en/msg_docs/OffboardControlMode) messages, while the actual setpoint is provided by publishing to one of the setpoint uORB topics, such as [TrajectorySetpoint](https://docs.px4.io/main/en/msg_docs/TrajectorySetpoint). In order to hold position in this case the vehicle must receive a stream of `OffboardControlMode` but would only need the `TrajectorySetpoint` once.
### ROS2 Messsages:

The following ROS 2 messages and their particular fields and field values are allowed for the specified frames. In addition to providing heartbeat functionality, `OffboardControlMode` has two other main purposes:
1. Controls the level of the [PX4 control architecture](https://docs.px4.io/main/en/flight_stack/controller_diagrams) at which offboard setpoints must be injected, and disables the bypassed controllers.
2. Determines which valid estimates (position or velocity) are required, and also which setpoint messages should be used.

The OffBoardControlMode Message are:
![[Pasted image 20260106125552.png]]

The fields are ordered in terms of priority such that `position` takes precedence over `velocity` and later fields, `velocity` takes precedence over `acceleration`, and so on. The first field that has a non-zero value (from top to bottom) defines what valid estimate is required in order to use offboard mode, and the setpoint message(s) that can be used. For example, if the `acceleration` field is the first non-zero value, then PX4 requires a valid `velocity estimate`, and the setpoint must be specified using the `TrajectorySetpoint` message.

#### Copter

- [px4_msgs::msg::TrajectorySetpoint](https://github.com/PX4/PX4-Autopilot/blob/main/msg/versioned/TrajectorySetpoint.msg)
    - The following input combinations are supported:
        - Position setpoint (`position` different from `NaN`). Non-`NaN` values of velocity and acceleration are used as feedforward terms for the inner loop controllers.
        - Velocity setpoint (`velocity` different from `NaN` and `position` set to `NaN`). Non-`NaN` values acceleration are used as feedforward terms for the inner loop controllers.
        - Acceleration setpoint (`acceleration` different from `NaN` and `position` and `velocity` set to `NaN`)
    - All values are interpreted in NED (Nord, East, Down) coordinate system and the units are `[m]`, `[m/s]` and `[m/s^2]` for position, velocity and acceleration, respectively.

- [px4_msgs::msg::VehicleAttitudeSetpoint](https://github.com/PX4/PX4-Autopilot/blob/main/msg/versioned/VehicleAttitudeSetpoint.msg)
    - The following input combination is supported:
        - quaternion `q_d` + thrust setpoint `thrust_body`. Non-`NaN` values of `yaw_sp_move_rate` are used as feedforward terms expressed in Earth frame and in `[rad/s]`.
    - The quaternion represents the rotation between the drone body FRD (front, right, down) frame and the NED frame. The thrust is in the drone body FRD frame and expressed in normalized [-1, 1] values.

- [px4_msgs::msg::VehicleRatesSetpoint](https://github.com/PX4/PX4-Autopilot/blob/main/msg/versioned/VehicleRatesSetpoint.msg)
    - The following input combination is supported:        
        - `roll`, `pitch`, `yaw` and `thrust_body`.
    - All the values are in the drone body FRD frame. The rates are in `[rad/s]` while thrust_body is normalized in `[-1, 1]`.

#### Actuator SetPoint

Instead of controlling the vehicle using position, speed, rate and other setpoints, you can directly control the motors and actuators using [ActuatorMotors](https://docs.px4.io/main/en/msg_docs/ActuatorMotors) and [ActuatorServos](https://docs.px4.io/main/en/msg_docs/ActuatorServos). In [OffboardControlMode](https://docs.px4.io/main/en/msg_docs/OffboardControlMode) set `direct_actuator` to _true_ and all other flags to _false_.

### MAVLink Messages

The following MAVLink messages and their particular fields and field values are allowed for the specified vehicle frames.
#### Copter/VTOL

- [SET_POSITION_TARGET_LOCAL_NED](https://mavlink.io/en/messages/common.html#SET_POSITION_TARGET_LOCAL_NED)
    - The following input combinations are supported:
        - Position setpoint (only `x`, `y`, `z`)
        - Velocity setpoint (only `vx`, `vy`, `vz`)
        - Acceleration setpoint (only `afx`, `afy`, `afz`)
        - Position setpoint **and** velocity setpoint (the velocity setpoint is used as feedforward; it is added to the output of the position controller and the result is used as the input to the velocity controller).
        - Position setpoint **and** velocity setpoint **and** acceleration (the velocity and the acceleration setpoints are used as feedforwards; the velocity setpoint is added to the output of the position controller and the result is used as the input to the velocity controller; the acceleration setpoint is added to the output of the velocity controller and the result used to compute the thrust vector).
    - PX4 supports the following `coordinate_frame` values (only): [MAV_FRAME_LOCAL_NED](https://mavlink.io/en/messages/common.html#MAV_FRAME_LOCAL_NED) and [MAV_FRAME_BODY_NED](https://mavlink.io/en/messages/common.html#MAV_FRAME_BODY_NED).
        
- [SET_POSITION_TARGET_GLOBAL_INT](https://mavlink.io/en/messages/common.html#SET_POSITION_TARGET_GLOBAL_INT)
    - The following input combinations are supported:
        - Positiin setpoint (only `lat_int`, `lon_int`, `alt`)
        - Velocity setpoint (only `vx`, `vy`, `vz`)
        - _Thrust_ setpoint (only `afx`, `afy`, `afz`)
        - Position setpoint **and** velocity setpoint (the velocity setpoint is used as feedforward; it is added to the output of the position controller and the result is used as the input to the velocity controller).
    - PX4 supports the following `coordinate_frame` values (only): [MAV_FRAME_GLOBAL](https://mavlink.io/en/messages/common.html#MAV_FRAME_GLOBAL)
- [SET_ATTITUDE_TARGET](https://mavlink.io/en/messages/common.html#SET_ATTITUDE_TARGET)
    - The following input combinations are supported:
        - Attitude/orientation (`SET_ATTITUDE_TARGET.q`) with thrust setpoint (`SET_ATTITUDE_TARGET.thrust`).
        - Body rate (`SET_ATTITUDE_TARGET` `.body_roll_rate` ,`.body_pitch_rate`, `.body_yaw_rate`) with thrust setpoint (`SET_ATTITUDE_TARGET.thrust`).

#### Fixed-wing
- [SET_POSITION_TARGET_LOCAL_NED](https://mavlink.io/en/messages/common.html#SET_POSITION_TARGET_LOCAL_NED)
    - The following input combinations are supported (via `type_mask`):
        - Position setpoint (`x`, `y`, `z` only; velocity and acceleration setpoints are ignored).
            - Specify the _type_ of the setpoint in `type_mask` (if these bits are not set the vehicle will fly in a flower-like pattern):
                The values are:
                - 292: Gliding setpoint. This configures TECS to prioritize airspeed over altitude in order to make the vehicle glide when there is no thrust (i.e. pitch is controlled to regulate airspeed). It is equivalent to setting `type_mask` as `POSITION_TARGET_TYPEMASK_Z_IGNORE`, `POSITION_TARGET_TYPEMASK_VZ_IGNORE`, `POSITION_TARGET_TYPEMASK_AZ_IGNORE`.
                - 4096: Takeoff setpoint.
                - 8192: Land setpoint.
                - 12288: Loiter setpoint (fly a circle centred on setpoint).
                - 16384: Idle setpoint (zero throttle, zero roll / pitch).
    - PX4 supports the coordinate frames (`coordinate_frame` field): [MAV_FRAME_LOCAL_NED](https://mavlink.io/en/messages/common.html#MAV_FRAME_LOCAL_NED) and [MAV_FRAME_BODY_NED](https://mavlink.io/en/messages/common.html#MAV_FRAME_BODY_NED).
        
- [SET_POSITION_TARGET_GLOBAL_INT](https://mavlink.io/en/messages/common.html#SET_POSITION_TARGET_GLOBAL_INT)
    - The following input combinations are supported (via `type_mask`):
        - Position setpoint (only `lat_int`, `lon_int`, `alt`)
            - Specify the _type_ of the setpoint in `type_mask` (if these bits are not set the vehicle will fly in a flower-like pattern):
                The values are:
                - 4096: Takeoff setpoint.
                - 8192: Land setpoint.
                - 12288: Loiter setpoint (fly a circle centred on setpoint).
                - 16384: Idle setpoint (zero throttle, zero roll / pitch).
    - PX4 supports the following `coordinate_frame` values (only): [MAV_FRAME_GLOBAL](https://mavlink.io/en/messages/common.html#MAV_FRAME_GLOBAL).
        
- [SET_ATTITUDE_TARGET](https://mavlink.io/en/messages/common.html#SET_ATTITUDE_TARGET)
    - The following input combinations are supported:
        - Attitude/orientation (`SET_ATTITUDE_TARGET.q`) with thrust setpoint (`SET_ATTITUDE_TARGET.thrust`).
        - Body rate (`SET_ATTITUDE_TARGET` `.body_roll_rate` ,`.body_pitch_rate`, `.body_yaw_rate`) with thrust setpoint (`SET_ATTITUDE_TARGET.thrust`).

### Offboard Parameters

![[Pasted image 20260106130517.png]]

---
## 2. ROS2 Offboard Control Example

The following C++ example shows how to do multicopter position control in [offboard mode](https://docs.px4.io/main/en/flight_modes/offboard) from a ROS 2 node. The example starts sending setpoints, enters offboard mode, arms, ascends to 5 meters, and waits. While simple, it shows the main principles of how to use offboard control and how to send vehicle commands.

### The Executable to generate the offboard control is:

``` cpp
/****************************************************************************
 *
 * Copyright 2020 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/**
 * @brief Offboard control example
 * @file offboard_control.cpp
 * @addtogroup examples
 * @author Mickey Cowden <info@cowden.tech>
 * @author Nuno Marques <nuno.marques@dronesolutions.io>
 */

#include <px4_msgs/msg/offboard_control_mode.hpp>
#include <px4_msgs/msg/trajectory_setpoint.hpp>
#include <px4_msgs/msg/vehicle_command.hpp>
#include <px4_msgs/msg/vehicle_control_mode.hpp>
#include <rclcpp/rclcpp.hpp>
#include <stdint.h>

#include <chrono>
#include <iostream>

using namespace std::chrono;
using namespace std::chrono_literals;
using namespace px4_msgs::msg;

class OffboardControl : public rclcpp::Node
{
public:
	OffboardControl() : Node("offboard_control")
	{

		offboard_control_mode_publisher_ = this->create_publisher<OffboardControlMode>("/fmu/in/offboard_control_mode", 10);
		trajectory_setpoint_publisher_ = this->create_publisher<TrajectorySetpoint>("/fmu/in/trajectory_setpoint", 10);
		vehicle_command_publisher_ = this->create_publisher<VehicleCommand>("/fmu/in/vehicle_command", 10);

		offboard_setpoint_counter_ = 0;

		auto timer_callback = [this]() -> void {

			if (offboard_setpoint_counter_ == 10) {
				// Change to Offboard mode after 10 setpoints
				this->publish_vehicle_command(VehicleCommand::VEHICLE_CMD_DO_SET_MODE, 1, 6);

				// Arm the vehicle
				this->arm();
			}

			// offboard_control_mode needs to be paired with trajectory_setpoint
			publish_offboard_control_mode();
			publish_trajectory_setpoint();

			// stop the counter after reaching 11
			if (offboard_setpoint_counter_ < 11) {
				offboard_setpoint_counter_++;
			}
		};
		timer_ = this->create_wall_timer(100ms, timer_callback);
	}

	void arm();
	void disarm();

private:
	rclcpp::TimerBase::SharedPtr timer_;

	rclcpp::Publisher<OffboardControlMode>::SharedPtr offboard_control_mode_publisher_;
	rclcpp::Publisher<TrajectorySetpoint>::SharedPtr trajectory_setpoint_publisher_;
	rclcpp::Publisher<VehicleCommand>::SharedPtr vehicle_command_publisher_;

	std::atomic<uint64_t> timestamp_;   //!< common synced timestamped

	uint64_t offboard_setpoint_counter_;   //!< counter for the number of setpoints sent

	void publish_offboard_control_mode();
	void publish_trajectory_setpoint();
	void publish_vehicle_command(uint16_t command, float param1 = 0.0, float param2 = 0.0);
};

/**
 * @brief Send a command to Arm the vehicle
 */
void OffboardControl::arm()
{
	publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0);

	RCLCPP_INFO(this->get_logger(), "Arm command send");
}

/**
 * @brief Send a command to Disarm the vehicle
 */
void OffboardControl::disarm()
{
	publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 0.0);

	RCLCPP_INFO(this->get_logger(), "Disarm command send");
}

/**
 * @brief Publish the offboard control mode.
 *        For this example, only position and altitude controls are active.
 */
void OffboardControl::publish_offboard_control_mode()
{
	OffboardControlMode msg{};
	msg.position = true;
	msg.velocity = false;
	msg.acceleration = false;
	msg.attitude = false;
	msg.body_rate = false;
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	offboard_control_mode_publisher_->publish(msg);
}

/**
 * @brief Publish a trajectory setpoint
 *        For this example, it sends a trajectory setpoint to make the
 *        vehicle hover at 5 meters with a yaw angle of 180 degrees.
 */
void OffboardControl::publish_trajectory_setpoint()
{
	TrajectorySetpoint msg{};
	msg.position = {0.0, 0.0, -5.0};
	msg.yaw = -3.14; // [-PI:PI]
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	trajectory_setpoint_publisher_->publish(msg);
}

/**
 * @brief Publish vehicle commands
 * @param command   Command code (matches VehicleCommand and MAVLink MAV_CMD codes)
 * @param param1    Command parameter 1
 * @param param2    Command parameter 2
 */
void OffboardControl::publish_vehicle_command(uint16_t command, float param1, float param2)
{
	VehicleCommand msg{};
	msg.param1 = param1;
	msg.param2 = param2;
	msg.command = command;
	msg.target_system = 1;
	msg.target_component = 1;
	msg.source_system = 1;
	msg.source_component = 1;
	msg.from_external = true;
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	vehicle_command_publisher_->publish(msg);
}

int main(int argc, char *argv[])
{
	std::cout << "Starting offboard control node..." << std::endl;
	setvbuf(stdout, NULL, _IONBF, BUFSIZ);
	rclcpp::init(argc, argv);
	rclcpp::spin(std::make_shared<OffboardControl>());

	rclcpp::shutdown();
	return 0;
}
```

PX4 4requires the number of setpoints that were already streaming before switch into Offboard mode. 
```cpp
offboard_setpoint_counter_
```

Create a timer callback every 100 ms
``` cpp
timer_ = this->create_wall_timer(100ms, timer_callback);
```

After 10 setpoints switch mode and arm, `param1 = 1` and `param2 = 6` are PX4/MAVLink mode parameters. In this example, `6` corresponds to **Offboard mode** in PX4’s “main mode” mapping used by this interface. Then it calls `arm()` which sends an arm command.
``` cpp 
if (offboard_setpoint_counter_ == 10) {
    this->publish_vehicle_command(VehicleCommand::VEHICLE_CMD_DO_SET_MODE, 1, 6);
    this->arm();
}
```

PX4 expects the control mode and setpoint to be consistent. Here it says “position control is active” and then sends a position setpoint.
``` cpp
publish_offboard_control_mode();
publish_trajectory_setpoint();
```

Arm/Disarm functions:
```cpp
publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0);
publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 0.0);
```

**publish_offboard_control_mode()** tells PX4 I am controlling position and altitude via z, don't use vel/acc/attitude/angular speed setpoints.
``` cpp
OffboardControlMode msg{};
msg.position = true;
msg.velocity = false;
msg.acceleration = false;
msg.attitude = false;
msg.body_rate = false;
msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
offboard_control_mode_publisher_->publish(msg);
```

**publish_trajectory_setpoint()** tells the position in the NED reference frame, in addition to the yaw rotation. 
``` cpp
TrajectorySetpoint msg{};
msg.position = {0.0, 0.0, -5.0};
msg.yaw = -3.14;
msg.timestamp = ...
trajectory_setpoint_publisher_->publish(msg);
```

**publish_vehicle_command()** tells the vehicle command similar to the COMMAND_LOG
``` cpp
VehicleCommand msg{};
msg.param1 = param1;
msg.param2 = param2;
msg.command = command;
msg.target_system = 1;
msg.target_component = 1;
msg.source_system = 1;
msg.source_component = 1;
msg.from_external = true;
msg.timestamp = ...
vehicle_command_publisher_->publish(msg);
```

---
## MAVROS
It is a extendable communication node with ROS2 with the next features:
- Communication with autopilot via serial port, UDP or TCP (e.g. [PX4 Pro](http://px4.io/) or [ArduPilot](http://ardupilot.com/))
- Internal proxy for Ground Control Station (serial, UDP, TCP)
- Plugin system for ROS-MAVLink translation
- Parameter manipulation tool
- Waypoint manipulation tool
- PX4Flow support (by [mavros_extras](https://github.com/mavlink/mavros/tree/master/mavros_extras))
- OFFBOARD mode support
- Geographic coordinates conversions.

### Coordinate Frames

MAVROS does translate Aerospace NED frames, used in FCUs to ROS ENU frames and vice-versa. For translate airframe related data we simply apply rotation 180° about ROLL (X) axis. For local we apply 180° about ROLL (X) and 90° about YAW (Z) axes. Please read documents from issue #473 for additional information. All the conversions are handled in `src/lib/ftf_frame_conversions.cpp` and `src/lib/ftf_quaternion_utils.cpp` and tested in `test/test_frame_conversions.cpp` and `test/test_quaternion_utils.cpp` respectively.

MAVROS also allows conversion of geodetic and geocentric coordinates through [GeographicLib](https://geographiclib.sourceforge.io/) given that:

- `geographic_msgs` and `NatSatFix.msg` require the LLA fields to be filled in WGS-84 datum, meaning that the altitude should be the height above the WGS-84 ellipsoid. For that, a conversion from the height above the geoid (AMSL, considering the egm96 geoid model) to height above the WGS-84 ellipsoid, and vice-versa, is available and used in several plugins;
- According to ROS REP 105, the `earth` frame should be propagated in ECEF (Earth-Centered, Earth-Fixed) local coordinates. For that, the functionalities of GeographicLib are used in order to allow conversion from geodetic coordinates to geocentric coordinates;
- The translation from GPS coordinates to local geocentric coordinates require the definition of a local origin on the `map` frame, in ECEF, and calculate the offset to it in ENU. All the conversions are supported by GeographicLib classes and methods and implemented in the `global_position` plugin.

### Programs

#### mavros_node – all-in-one container[](https://docs.ros.org/en/jazzy/p/mavros/?utm_source=chatgpt.com#mavros-node-all-in-one-container "Link to this heading")

That is a preconfigured composite node contaier, which provides similar parameters as ROS1 mavros_node. That container loads Router, UAS and configures them to work together (sets uas_link, etc.). Main node. Allow disable GCS proxy by setting empty URL.

``` bash
ros2 run mavros mavros_node --ros-args --params-file params.yaml
```

### Launch files

**XXX TODO**! #1564

Launch files are provided for use with common FCUs, in particular [Pixhawk](https://docs.ros.org/en/jazzy/p/mavros/?utm_source=chatgpt.com#pixhawk):

- [px4.launch](https://docs.ros.org/en/jazzy/p/mavros/?utm_source=chatgpt.com#launch/px4.launch) – for use with the PX4 Autopilot (for VTOL, multicopters and planes)
- [apm.launch](https://docs.ros.org/en/jazzy/p/mavros/?utm_source=chatgpt.com#launch/apm.launch) – for use with APM flight stacks (e.g., all versions of ArduPlane, ArduCopter, etc)

Examples:
roslaunch mavros px4.launch
roslaunch mavros apm.launch fcu_url:=tcp://localhost gcs_url:=udp://@

---
## Tutorial ROS2 and PX4

Remember to do the [ROS2 and PX4 Tutorial | Simulated Offboard Mode](https://www.youtube.com/watch?v=8gKIP0OqHdQ) to check the PX4 and ROS2 configuration'

