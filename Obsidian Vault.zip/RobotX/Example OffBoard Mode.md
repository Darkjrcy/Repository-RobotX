---
tags:
  - Robotx
  - PX4
created: 2026-01-08 11:04
---

# Example OffBoard Mode

---
### Important
Remember to install MAVROS before start working:
``` bash
sudo apt update
sudo apt install -y ros-humble-mavros ros-humble-mavros-extras
```

Install Gegraphic Lib Datasets that MAVROS requires
``` bash
sudo /opt/ros/humble/lib/mavros/install_geographiclib_datasets.sh
```

## Steps to start a simple OffBoard Example

1. Start the gz_x500 simulation.
2. Connect the MAVROS
	``` bash
	ros2 run mavros mavros_node --ros-args \
  -p fcu_url:=udp://:14540@127.0.0.1:14557 \
  -p gcs_url:=udp://@127.0.0.1:14550
	```
3. Now for the Offboard example
