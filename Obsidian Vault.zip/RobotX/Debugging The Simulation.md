---
tags:
  - Robotx
created: 2026-01-05 09:44
---

# Debugging The Simulation

---

## Understanding messages:

**ERRORS:**
![[Pasted image 20260105095018.png]]
This error shows that the PX4 is not receiving barometer outputs so the EKF can't work properly. This means that Gazebo sensors are nor connected with px4. You can 
