---
tags:
  - Robotx
created: 2026-01-28 15:39
---

# Landing Library

---

## Landing System

### 1st. Add an AprilTag to Gazebo sim.
To create a model of an AprilTag inside Gazebo first isntall the library in the RobotX folder:
``` bash
git clone https://github.com/mikaelarguedas/gazebo_models.git
cd ~/gazebo_models/ar_tags/scripts
chmod +x generate_markers_model.py
```

Eliminate all the images from the folder /ar_tags/images
``` bash
rm /home/adcl/RobotXProject/gazebo_models/ar_tags/images/*
```

Now download the image repository from:
``` bash
git clone https://github.com/AprilRobotics/apriltag-imgs.git
```

Install the resize system in Ubuntu using ImageMagick 7+:
``` bash
sudo apt update
sudo apt install imagemagick
```

Now open the folder apriltag-imgs and resize the required image. 
``` bash
cd ~/RobotXProject/apriltag-imgs/
convert <PATH TO THE IMAGE.png> -filter point -resize 2200% <PATH RESULT.png>
mv <PATH RESULT.png> ~/RobotXProject/gazebo_models/ar_tags/images/
```

Now lets use that image to crate the gz model:
```bash
cd ~/RobotXProject/gazebo_models/ar_tags/scripts/
python3 ./generate_markers_model.py \
  -i <IMAGE FOLDER DIRECTORY>\
  -g ~/RobotXProject/ros2_ws/src/vrx/vrx_urdf/wamv_description/models \
  -s 200 \ # square sze of the image in mm
  -v
```

**NOTE:** If you want to look at it in the gz sim 7 please use the next command to source the gazebo dictionary:
``` bash
GZ_SIM_RESOURCE_PATH=<PATH TO MODELS>:$GZ_SIM_RESOURCE_PATH \
IGN_GAZEBO_RESOURCE_PATH=<PATH TO MODELS>:$IGN_GAZEBO_RESOURCE_PATH \
gz sim -v 4 /home/adcl/RobotXProject/ros2_ws/src/vrx/vrx_urdf/wamv_description/models/marker0/model.sdf

```

**Note:** To add an AprilTag you can use an AprilTag spanner that creates a fixed link using the  "wamv/base_link". However a simpler version is to modify the urdf files in the share directory using a ROS2 dummy node that spawns tha apriltags from the original version. The launch file is presented in usv_px4_apriltags.launch.py:
``` bash
ros2 launch robotx_bringup usv_px4_apriltags.launch.py 
```

### 2nd Add the Camera to the x500 quadcopter:
If you use the g_x500_cam, the camera is oriented in the x axis, as the objective is to look down the camera orientation can be modify it inside the x500_mono_cam sdf of both the vrx library (added previously) and the px4 repository. You need to change:
``` xml
<model name='x500_mono_cam'>
    <include merge='true'>
      <uri>x500</uri>
    </include>
    <include merge='true'>
      <uri>model://mono_cam</uri>
      <pose>.12 .03 .242 0 0 0</pose>
    </include>
    <joint name="CameraJoint" type="fixed">
      <parent>base_link</parent>
      <child>mono_cam/base_link</child>
      <pose relative_to="base_link">.12 .03 .242 0 0 0</pose>
    </joint>
</model>
```

And rotate it respect to the y axes 90 deg.
``` xml
<model name='x500_mono_cam'>
    <include merge='true'>
      <uri>x500</uri>
    </include>
    <include merge='true'>
      <uri>model://mono_cam</uri>
      <pose>.12 .03 .242 0 1.571 0</pose>
    </include>
    <joint name="CameraJoint" type="fixed">
      <parent>base_link</parent>
      <child>mono_cam/base_link</child>
      <pose relative_to="base_link">.12 .03 .242 0 1.571 0</pose>
    </joint>
</model>
```

### 3rd Decode the Launch file:

Important messages:
- ArTag.msg: It has a header, the family names, ceters of teh AprilTag, if the AprilTag os detected, the duration of the detection, if it was previously detected and teh total number of tags.:
	``` 
	std_msgs/Header header
	string[] family_names
	Center[] centers
	bool detected
	float64 duration
	bool previously_detected
	int64 total_tags
	```


There are 4 main files launched from the landing.launch:
- AprilTag_Landing: Its an executable that sees if it reacjhes the actual way-point or don't see the apriltag to send the next way-point in the "/minion/kevin/fly_to_wp" topic. In case it sees the AprilTag it stops sending permision and it changes to another controller.

- FLy_to_waypoint: Is  a bridge between the AprilTag detection, PX4 via MAVROS, it receives the GPS waypoint of the USV and then it pushes the position of the USV to the PX4 as a mission (single Waypoint) with he AUTO.MISSION, after the mission is completed it changes to vehicle mode AUTO.LOITER. The start of the condition changes depending on the mavros state and if the UAV is armed.

- Detect_AprilTag: It runs an AprilTag detector to estimate the altitude and publish the results. The detections are published in an ArTag message witht eh information realted to later start the landing condition. 

- pid_controls: This script is basically the **“landing controller” node** that uses your AprilTag detections + estimated altitude to **align, hover, and then command AUTO.LAND** through MAVROS. 

#### Required dependencies:
The landing strategy requires a variety of ROS2 dependencies. To install them you have to follow the next commands:

The MAVSDK libarry to use the MAVLink libarries:
``` bash
cd ~/RobotXProject/ros2_ws/src
git clone https://github.com/mavlink/MAVSDK.git
cd MAVSDK
git checkout v3.14.0
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)
sudo make install
```

Remember that your MAVSDK labrry requires to be in the 

The px4 messages requires in ros2:
``` bash
# px4_msgs (match PX4 v1.15.x)
git clone https://github.com/PX4/px4_msgs.git
cd px4_msgs && git checkout release/1.15 && cd ..
```


**NOTE:** TO enable the use the commands made by PX4 to change the flight mode using the micro-xcre. Install it:
``` bash
sudo snap install micro-xrce-dds-agent --edge
```
Turn it on using teh next command that is already embedded in the launch file of the main_usv_px4.
``` bash
micro-xrce-dds-agent udp4 -p 8888
```
IN the launch file you can see it as, it works as a bridge that converts DDS ROS2 and PX4 internal message:
``` python
# Start Micro XRCE-DDS Agent (needed for /fmu/* ROS 2 topics)
    xrce_agent = ExecuteProcess(
        cmd=[
            'bash', '-lc',
            # Try snap name first; if not found, try the source-install name
            'command -v micro-xrce-dds-agent >/dev/null 2>&1 && '
            'micro-xrce-dds-agent udp4 -p 8888 '
            '|| MicroXRCEAgent udp4 -p 8888'
        ],
        output='screen'
    )
    launch_process.append(xrce_agent)

```


### 4th Add the AprilTag detection system:
After the landing system start following the GPS position of the USV, at some point it would change to a combined approach where it uses both the GPS positioning and the USV states coming from the AprilTag detection. First, install the AprilTag detector libraries with ROS2:
``` bash
sudo apt update
sudo apt install ros-humble-apriltag
sudo apt install ros-humble-cv-bridge ros-humble-sensor-msgs ros-humble-apriltag-msgs
```

Install the Official C library form source:
``` bash
git clone https://github.com/AprilRobotics/apriltag.git
cd apriltag
mkdir build
cd build
cmake ..
make -j$(nproc)
sudo make install
```

### 5th Landing Maneuver:
There are two ways of using the ladning maneuver in the px4_exec, The MAVSDK executable that can land using commands and the Follow me command to follow the USV. However, the main system that is being developeb is the **landing_strategy.cpp** where px4_msgs to command the position fo teh USV and develop a simple landing strategy. To run this node you require the GPS position of teh UAV and the USV topics and the Micro XRCE-DDS Agent to connect to the PX4 commands. To run the landing strategy after launching the **usv_px4_apriltags.launch.py** and then do:

```bash
 ros2 run px4_exec landing_strategy
```
